/*  
 * rectangle.h
 * lab 2 Exercie B
 * Completed by: Alessandra Schiavi and Muhammed Umar Khan
 * Submission Date: Sept 23, 2024
 */
#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H

class GraphicsWorld {
public:
    void run();
};

#endif
