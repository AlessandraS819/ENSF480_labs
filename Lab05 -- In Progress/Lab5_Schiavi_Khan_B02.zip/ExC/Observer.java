/*  
 * Lab05 ExC
 * Completed by: Alessandra Schiavi and Muhammed Umar Khan
 * Submission Date: Oct 28, 2024
 */
import java.util.ArrayList;

public interface Observer {
    void update(ArrayList<Double> data);   
}
