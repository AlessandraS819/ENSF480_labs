//compmay.cpp
#include <string>
#include <vector>

using namespace std;

class Company{
    private:
        Address companyAddress;
        Name companyName;
        vector <Employee> employeeList;
        Date dateEstablished;
        vector <Customer> customerList;

    public: 
        //constructor & setters and getters
};


class Person {
  protected:
    Name name;
    Address address;

  public:
    //setters and getters
};

class Employee : public Person {
  private:
    Date DOB;
    string status;

  public:
    //setters and getters
};

class Customer : public Person {
  private:
    PhoneNumber phone;

  public:
    //setters and getters
};


class Name{
    private:
        string fName;
        string lName = "";

    public:
        //setters and getters
};

class Address{
    private:
        string unit;
        string street;
        string country;
        string postal;
    public:
        //setters and getters
};

class Date{
    private:
        int day;
        int month;
        int year;
    public:
        //setters and getters
};

class PhoneNumber{
    private:
        int areaCode;
        int prefix;
        int number;
};