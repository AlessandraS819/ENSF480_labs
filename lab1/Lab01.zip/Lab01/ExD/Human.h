//Human.h

#ifndef HUMAN_H
#define HUMAN_H

#include <string>
#include "Point.h"

class Human {
private:
    Point location; // Location of an object of Human on a Cartesian Plain
    std::string name; // Human's name

public:
    Human(const std::string& nam = "", double x = 0, double y = 0);

    // Copy constructor
    Human(const Human& other);

    // Assignment operator
    Human& operator=(const Human& other);

    // Destructor
    ~Human();

    std::string get_name() const;
    void set_name(const std::string& name);
    Point get_point() const;
    void display() const;
};

#endif // HUMAN_H
