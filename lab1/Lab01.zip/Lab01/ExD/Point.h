//Point.h

#ifndef POINT_H
#define POINT_H

class Point {
private:
    double x; // x coordinate of a location on Cartesian Plain
    double y; // y coordinate of a location on Cartesian Plain

public:
    Point(double a = 0, double b = 0);

    double get_x() const;
    double get_y() const;
    void set_x(double a);
    void set_y(double a);
};

#endif // POINT_H
