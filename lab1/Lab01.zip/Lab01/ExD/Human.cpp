//Human.cpp

#include "Human.h"
#include <iostream>

Human::Human(const std::string& nam, double x, double y)
    : name(nam), location(x, y) {}

Human::Human(const Human& other)
    : name(other.name), location(other.location) {}

Human& Human::operator=(const Human& other) {
    if (this != &other) {
        name = other.name;
        location = other.location;
    }
    return *this;
}

Human::~Human() {}

std::string Human::get_name() const { return name; }
void Human::set_name(const std::string& newName) { name = newName; }
Point Human::get_point() const { return location; }
void Human::display() const {
    std::cout << "Human Name: " << name << "\nHuman Location: "
              << location.get_x() << " , "
              << location.get_y() << ".\n" << std::endl;
}
