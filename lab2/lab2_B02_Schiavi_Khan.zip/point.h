
#include <iostream>
#include <string>
using namespace std;

#ifndef POINT_H
#define POINT_H
class Point{
	private:
		static int nextId;
		double x;
		double y;
		int id;
		static int num_obj;
	
	public:
		Point (int x, int y);
		// calls the setter and getter for the x and y and makes them double 
		// sets the id and then increments the static nextId variable
		void set_x(int num);
		void set_y(int num);
		double get_x() const;
		double get_y()const;
		double get_id()const;
		double calc_distance (const Point& m, const Point& n);
		// promises: calculates the distance between two cartesian points
		// calculation: d= ((x2-x1)^2 + (y2-y1)^2)^1/2
	
}
	
	