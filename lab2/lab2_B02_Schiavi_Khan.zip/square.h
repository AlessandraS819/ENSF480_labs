#include <iostream>
#include <string>
#include "shape.h"
#include "point.h"
using namespace std;

class Square: public Shape{
	private: 
	int side_a;
	
	public:
	Square(int x, int y, int side1, char* name);
	double area(int side);
	// the area is side* side 
	double perimeter(int side);
	//perimeter = 4* side
	int get_side_a() const;
	void display() const override;
	void move(double dx, double dy) override;
}