#include <iostream>
#include <string>
#include "shape.h"
#include "point.h"
#include <cmath>
using namespace std;

Shape::Shape(int x, int y, char*s){
	origin.set_x(x);
	origin.set_y(y);
	size_t length =strlen(s);
	shapeName= new char[length +1];
	strcpy(shapeName, s)
}
Shape::~Shape()
{
  delete[] shapeName;
}
	
char* Shape::getName()const {return *shapeName};

char* Shape::get_x()const {return origin.get_x()};

char* Shape::get_y()const {return origin.get_y()};

double Shape::distance(Shape &other){
	double x_squared = pow(other.origin.x, 2);
	double y_sqared = pow(other.origin.y, 2);
	double sum = x_squared + y_sqared;
	double distance = sqrt(sum);
	return distance;
}
static double Shape:: distance(Shape& the_shape, Shape& other){
	
}

virtual void Shape:: move(double dx, double dy){
	origin.set_x(origin.x + dx);
    origin.set_y(origin.y + dy);
	
}// virtual function

virtual void Shape::display() const{
	cout << "Shape Name: " << getName()<< "x-coordinate: " << get_x() << "y-coordinate: " << get_y()<<endl;
}// virtual funciton