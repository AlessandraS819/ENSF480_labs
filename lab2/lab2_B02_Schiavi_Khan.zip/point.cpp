#include <iostream>
#include "point.h"
#include <cmath>

using namespace std;

int Point :: nextId = 1001; //initialize the value of nextId
int Point::num_obj = 0;// initialize object count

Point:: Point(int x, int y):{
	set_x(x);
	set_y(y);
	id = nextId++
	num_obj++
}

void Point::set_x(int num){
	x = num;
}

void Point::set_y(int num){
	y = num;
}

	
double Point::get_x() const {return x;}
double Point::get_y()const {return y;}
int Point::get_id()const {return id;}

double Point::calc_distance (const Point& m, const Point& n){
	//calculates the distance between two points
	//d= ((x2-x1)^2 + (y2-y1)^2)^1/2
	double x_diff = m.x - n.x;
	double y_diff = m.y - n.y;
	double distance = sqrt(pow(x_diff, 2) + pow(y_diff, 2));
	
	return distance;
}
