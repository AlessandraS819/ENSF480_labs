#include <iostream>
#include <string>
#include "shape.h"
#include "point.h"
#include "square.h"
using namespace std;
 Square::Square(int x, int y, int side1, const char* name) : Shape(x, y, name), side_a(side1) {}

double Square::area() const {
	return side_a * side_a; // Area = side * side
}

double Square::perimeter() const {
	return 4 * side_a; // Perimeter = 4 * side
}

int Square::get_side_a() const {
	return side_a;
}

void Square::display() const override {
	cout << "Shape Name: " << getName()<< "x-coordinate: " << origin.get_x() << "y-coordinate: " << origin.get_y() << "Side: " << side_a 
		 << ", Area: " << area() << ", Perimeter: " << perimeter() << endl;
}

void Square::move(double dx, double dy) override {
	origin.set_x(origin.x + dx);
	origin.set_y(origin.y + dy);
}
