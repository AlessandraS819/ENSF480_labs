#include <iostream>
#include <string>
#include "shape.h"
#include "point.h"
using namespace std;

class Rectangle: public Shape{
	private: 
	int side_a;
	int side_b;
	
	Square(int x, int y, int side1, int side2, char* name); // must call parent constructor for x,y and char*
	double area(int side1, int side2);
	// the area is side* side 
	double perimeter(int side1, int side2);
	//perimeter = 2* side + 2*side2
	int get_side_a() const;
	int get_side_b() const;
	void display();
}