#include <iostream>
#include <string>
using namespace std;

class Shape{
	friend class Point;
	protected:
	Point origin(0, 0);
	char* shapeName;
	
	public:
	Shape(int x, int y, char* s);
	virtual ~Shape();
	char* getName()const;
	double get_x()const;
	double get_y()const;
	double distance(Shape &other);
	static double distance(Shape& the_shape, Shape& other)'
	virtual void move(double dx, double dy);// virtual function
	virtual void display() const;// virtual funciton
}